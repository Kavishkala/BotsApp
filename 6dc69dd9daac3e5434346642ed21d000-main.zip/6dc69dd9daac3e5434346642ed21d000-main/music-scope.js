case 'musicscope': {
 if (!text) return reply(`Contoh: .musicscope Judul|Artis|URL_Gambar (balas audio)`)

 let [title, artist, imgUrl] = text.split('|').map(v => v.trim())
 if (!title || !artist || !imgUrl) return reply(`Contoh: .musicscope Judul|Artis|URL_Gambar (balas audio)`)

 let q = m.quoted ? m.quoted : m
 let mime = (q.msg || q).mimetype || ''
 if (!/^audio/.test(mime)) return reply('Balas dengan audio MP3-nya.')

 const api_url = 'https://ziqiangao-musicscopegen.hf.space/gradio_api'
 const file_url = 'https://ziqiangao-musicscopegen.hf.space/gradio_api/file='

 const generateSession = () => Math.random().toString(36).substring(2)

 const uploadFile = async (buffer, filename) => {
 const upload_id = generateSession()
 const form = new (require('form-data'))()
 form.append('files', buffer, filename)
 const res = await fetch(`${api_url}/upload?upload_id=${upload_id}`, {
 method: 'POST',
 headers: form.getHeaders(),
 body: form
 })
 const json = await res.json()
 return {
 orig_name: filename,
 path: json[0],
 url: `${file_url}${json[0]}`
 }
 }

 try {
 reply('⏳ Sedang memproses audio...')

 const audioBuffer = await q.download()
 const imageBuffer = await (await fetch(imgUrl)).arrayBuffer()

 const audioFile = await uploadFile(audioBuffer, `${Date.now()}.mp3`)
 const imageFile = await uploadFile(imageBuffer, `${Date.now()}.jpg`)
 const session = generateSession()

 await fetch(`${api_url}/queue/join`, {
 method: 'POST',
 headers: { 'Content-Type': 'application/json' },
 body: JSON.stringify({
 data: [
 {
 path: audioFile.path,
 url: audioFile.url,
 orig_name: audioFile.orig_name,
 size: audioBuffer.length,
 mime_type: 'audio/mpeg',
 meta: { _type: 'gradio.FileData' }
 },
 null,
 'Output',
 30,
 1280,
 720,
 1024,
 {
 path: imageFile.path,
 url: imageFile.url,
 orig_name: imageFile.orig_name,
 size: imageBuffer.length,
 mime_type: 'image/jpeg',
 meta: { _type: 'gradio.FileData' }
 },
 title,
 artist
 ],
 event_data: null,
 fn_index: 0,
 trigger_id: 26,
 session_hash: session
 })
 })

 const resultRes = await fetch(`${api_url}/queue/data?session_hash=${session}`)
 const raw = await resultRes.text()

 let result
 const lines = raw.split('\n\n')
 for (const line of lines) {
 if (line.startsWith('data:')) {
 const d = JSON.parse(line.slice(6))
 if (d.msg === 'process_completed') result = d.output.data[0].video.url
 }
 }

 if (!result) throw new Error('Gagal mendapatkan video.')

 await VarShade.sendMessage(m.chat, {
 video: { url: result },
 caption: `🎶 *Musicscope Generated*\n\n📌 Judul: ${title}\n👤 Artis: ${artist}\n\nDiproses oleh: ${global.botname}`
 }, { quoted: m })
 } catch (e) {
 console.error(e)
 reply(`❌ Gagal memproses Musicscope:\n${e.message}`)
 }
}
break